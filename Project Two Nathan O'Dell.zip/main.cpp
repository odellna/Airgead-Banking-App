/*
Nathan O'Dell
CS-210
02/08/26
Airgead Banking Application
*/
#include <iostream>
#include "BankingApp.h"

using namespace std;

int main() {

    char choice = 'y';

    while (choice == 'y' || choice == 'Y') {

        SetColor(10);
        cout << "========== Airgead Banking App ==========\n";

        SetColor(15);

        BankingApp app;

        app.GetUserInput();

        cout << "\nPress Enter to continue...";
        cin.ignore();
        cin.get();

        app.DisplayReports();

        cout << "\nRun again? (y/n): ";
        cin >> choice;
    }

    return 0;
}