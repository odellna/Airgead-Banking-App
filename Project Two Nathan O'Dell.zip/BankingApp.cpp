/*
Nathan O'Dell
CS-210
02/08/26
Airgead Banking Application
*/
#include <iostream>
#include <iomanip>
#include <windows.h>
#include "BankingApp.h"

using namespace std;

// SINGLE definition lives here
void SetColor(int color) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color);
}

BankingApp::BankingApp() {
    initialInvestment = 0.0;
    monthlyDeposit = 0.0;
    annualInterest = 0.0;
    years = 0;
}

void BankingApp::GetUserInput() {

    SetColor(10);

    cout << "**********************************\n";
    cout << "************ Data Input **********\n";

    SetColor(15);

    cout << "Initial Investment Amount: ";
    cin >> initialInvestment;

    cout << "Monthly Deposit: ";
    cin >> monthlyDeposit;

    cout << "Annual Interest (%): ";
    cin >> annualInterest;

    cout << "Number of years: ";
    cin >> years;
}

void BankingApp::DisplayReports() const {

    SetColor(10);
    cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
    cout << "========================================================\n";

    SetColor(15);
    PrintReport(0.0);

    SetColor(10);
    cout << "\nBalance and Interest With Additional Monthly Deposits\n";
    cout << "=====================================================\n";

    SetColor(15);
    PrintReport(monthlyDeposit);
}

void BankingApp::PrintReport(double monthly) const {

    double balance = initialInvestment;
    double monthlyRate = (annualInterest / 100) / 12;

    cout << left
        << setw(8) << "Year"
        << setw(20) << "Year End Balance"
        << setw(20) << "Year End Earned Interest"
        << endl;

    for (int year = 1; year <= years; year++) {

        double yearlyInterest = 0;

        for (int month = 0; month < 12; month++) {

            balance += monthly;

            double interest = balance * monthlyRate;

            yearlyInterest += interest;
            balance += interest;
        }

        cout << fixed << setprecision(2);

        cout << left
            << setw(8) << year
            << "$" << setw(19) << balance
            << "$" << yearlyInterest
            << endl;
    }
}
