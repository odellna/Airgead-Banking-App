
/*
Nathan O'Dell
CS-210
02/08/26
Airgead Banking Application
*/
#ifndef BANKING_APP_H
#define BANKING_APP_H

// function declaration (DEFINED in BankingApp.cpp)
void SetColor(int color);

class BankingApp {

private:
    double initialInvestment;
    double monthlyDeposit;
    double annualInterest;
    int years;

    void PrintReport(double monthly) const;

public:
    BankingApp();

    void GetUserInput();
    void DisplayReports() const;
};

#endif
